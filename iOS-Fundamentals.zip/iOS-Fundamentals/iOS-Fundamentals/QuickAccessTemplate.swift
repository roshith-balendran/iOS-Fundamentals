//
//  QuickAccessTemplate.swift
//  iOS-Fundamentals
//
//  Created by Roshith Balendran on 27/11/18.
//  Copyright © 2018 Roshith Balendran. All rights reserved.
//

import Foundation
import UIKit

class QuickAccessTemplate {
    
}
