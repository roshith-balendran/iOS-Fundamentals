//
//  AnimatedSplashScreenViewController.swift
//  iOS-Fundamentals
//
//  Created by Roshith Balendran on 27/11/18.
//  Copyright © 2018 Roshith Balendran. All rights reserved.
//

import UIKit

class AnimatedSplashScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
